export default {
  zinc: '#0c0c1b',
  black: '#000',
  white:'#FFF',
  green:'#99CF1D',
  gray: '#DDDDDD',

};
